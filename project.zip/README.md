# VPN Store: A Flask-Based VPN Subscription Web App

#### Video Demo: <URL HERE>  // بعد از آپلود ویدیو بگذار

#### Description:
This project is a web application for selling VPN subscriptions, built using Flask, SQLite, HTML, CSS (with Bootstrap), and JavaScript. It allows users to register, log in, view and purchase subscription plans, manage their profiles, and download config files. There's also an admin panel for managing users, orders, and plans. The goal is to create a simple yet functional e-commerce site for VPN services, simulating the entire process from user registration to subscription activation.

I chose Flask because it's lightweight and easy to use for web development, as taught in CS50 Week 9. It handles routing, templates, and sessions well. SQLite was selected for the database since it's serverless and perfect for a small-scale app. Bootstrap makes the UI clean and responsive without much custom CSS.

#### Pages and Features:
- **Home Page (/)**: Welcomes users and provides navigation.
- **Register (/register)**: Form for new users to sign up with email and password (hashed).
- **Login (/login)**: Authenticates users and starts a session.
- **Plans (/plans)**: Displays available subscription plans (Monthly, Quarterly, Yearly).
- **Profile (/profile)**: Shows active subscription details, expiration date, orders history, and a link to download VPN config (simulated).
- **Order (/order/<plan_id>)**: Creates an order and simulates payment (Paid or Failed). On success, activates subscription.
- **Admin Login (/admin/login)**: Simple login for admin (hardcoded for demo).
- **Admin Dashboard (/admin)**: Lists users, orders, plans. Allows editing plans and toggling user subscriptions.
- **Logout (/logout)**: Clears session.

#### Database Tables:
- **users**: id, email, password_hash, created_at – Stores user info with hashed passwords.
- **plans**: id, name, price, duration_days – Predefined plans.
- **orders**: id, user_id, plan_id, status, created_at – Tracks orders and payment status.
- **subscriptions**: id, user_id, plan_id, start_date, end_date, active – Manages active subscriptions.

Data is stored persistently in database.db. On app start, tables are created if missing, and default plans are inserted.

#### Why Flask?
Flask is minimalistic, allowing quick setup of routes and integration with SQLite. It supports sessions for auth and Jinja for templates, making it ideal for this project.

#### Challenges:
- Implementing secure auth: Learned to use werkzeug for hashing.
- Handling dates for subscriptions: Used datetime and timedelta.
- Simulating payment: Kept it simple with form choices to avoid real APIs.
- Admin security: Hardcoded for demo, but in real-world, I'd use proper user roles.
- Validation: Added server-side checks for unique emails and client-side required fields.

#### Future Improvements:
- Integrate real payment gateway (e.g., Stripe).
- Add email verification for registrations.
- Generate real VPN configs dynamically.
- Improve admin auth with roles in users table.
- Add search/filter in admin panel.
- Deploy to Heroku or similar.

This project took about 20 hours, drawing from CS50 lessons on Python, SQL, and Flask. It's fully executable locally with `flask run`. I aimed for simplicity while covering all requirements.

(Expand this to ~750 words by adding more details on design choices, code snippets explanations, etc.)