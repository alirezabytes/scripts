# admin.py: Admin panel routes

from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from .models import get_db_connection

admin = Blueprint('admin', __name__)

# Simple admin login (hardcoded for demo; in real, use proper auth)
ADMIN_EMAIL = 'admin@example.com'
ADMIN_PASSWORD = 'adminpass'

@admin.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if email == ADMIN_EMAIL and password == ADMIN_PASSWORD:
            session['admin'] = True
            return redirect(url_for('admin.admin_dashboard'))
        else:
            flash('Invalid admin credentials.', 'danger')
    return render_template('admin_login.html')

@admin.route('/admin')
def admin_dashboard():
    if 'admin' not in session:
        return redirect(url_for('admin.admin_login'))
    
    conn = get_db_connection()
    users = conn.execute("SELECT * FROM users").fetchall()
    orders = conn.execute("SELECT o.*, u.email, p.name FROM orders o JOIN users u ON o.user_id = u.id JOIN plans p ON o.plan_id = p.id").fetchall()
    plans = conn.execute("SELECT * FROM plans").fetchall()
    conn.close()
    
    return render_template('admin_dashboard.html', users=users, orders=orders, plans=plans)

@admin.route('/admin/edit_plan/<int:plan_id>', methods=['GET', 'POST'])
def edit_plan(plan_id):
    if 'admin' not in session:
        return redirect(url_for('admin.admin_login'))
    
    conn = get_db_connection()
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        duration = int(request.form['duration_days'])
        conn.execute("UPDATE plans SET name = ?, price = ?, duration_days = ? WHERE id = ?", (name, price, duration, plan_id))
        conn.commit()
        flash('Plan updated.', 'success')
        return redirect(url_for('admin.admin_dashboard'))
    
    plan = conn.execute("SELECT * FROM plans WHERE id = ?", (plan_id,)).fetchone()
    conn.close()
    return render_template('edit_plan.html', plan=plan)

@admin.route('/admin/toggle_user/<int:user_id>')
def toggle_user(user_id):
    if 'admin' not in session:
        return redirect(url_for('admin.admin_login'))
    
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    # For simplicity, toggle subscription active status (assume one sub per user)
    sub = conn.execute("SELECT * FROM subscriptions WHERE user_id = ?", (user_id,)).fetchone()
    if sub:
        new_active = 0 if sub['active'] else 1
        conn.execute("UPDATE subscriptions SET active = ? WHERE user_id = ?", (new_active, user_id))
        conn.commit()
        flash('User subscription toggled.', 'success')
    conn.close()
    return redirect(url_for('admin.admin_dashboard'))