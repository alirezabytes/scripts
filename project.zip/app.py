# app.py: Main application file for VPN Store

from flask import Flask
from .models import init_db
from .auth import auth
from .routes import routes
from .admin import admin

app = Flask(__name__)
app.secret_key = 'super_secret_key'  # Change in production

# Register blueprints
app.register_blueprint(auth)
app.register_blueprint(routes)
app.register_blueprint(admin)

# Initialize database
init_db()

if __name__ == '__main__':
    app.run(debug=True)