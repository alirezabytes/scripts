# routes.py: Main routes for users and subscriptions

from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from .models import get_db_connection
from datetime import datetime, timedelta

routes = Blueprint('routes', __name__)

@routes.route('/')
def index():
    return render_template('index.html')

@routes.route('/plans')
def plans():
    conn = get_db_connection()
    plans = conn.execute("SELECT * FROM plans").fetchall()
    conn.close()
    return render_template('plans.html', plans=plans)

@routes.route('/profile')
def profile():
    if 'user_id' not in session:
        flash('Please log in first.', 'danger')
        return redirect(url_for('auth.login'))
    
    conn = get_db_connection()
    subscription = conn.execute("""
        SELECT s.*, p.name, p.duration_days 
        FROM subscriptions s 
        JOIN plans p ON s.plan_id = p.id 
        WHERE s.user_id = ? AND s.active = 1
        ORDER BY s.start_date DESC LIMIT 1
    """, (session['user_id'],)).fetchone()
    
    orders = conn.execute("SELECT o.*, p.name FROM orders o JOIN plans p ON o.plan_id = p.id WHERE o.user_id = ?", (session['user_id'],)).fetchall()
    conn.close()
    
    config_link = "vpn_config.ovpn" if subscription else None  # Simulated config file
    
    return render_template('profile.html', subscription=subscription, orders=orders, config_link=config_link)

@routes.route('/order/<int:plan_id>', methods=['GET', 'POST'])
def order(plan_id):
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    if request.method == 'POST':
        status = request.form['status']  # 'Paid' or 'Failed' from form
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO orders (user_id, plan_id, status) VALUES (?, ?, ?)", (session['user_id'], plan_id, status))
        
        if status == 'Paid':
            # Activate subscription
            plan = conn.execute("SELECT * FROM plans WHERE id = ?", (plan_id,)).fetchone()
            start = datetime.now()
            end = start + timedelta(days=plan['duration_days'])
            cursor.execute("INSERT INTO subscriptions (user_id, plan_id, start_date, end_date) VALUES (?, ?, ?, ?)",
                           (session['user_id'], plan_id, start, end))
            flash('Subscription activated!', 'success')
        else:
            flash('Payment failed.', 'danger')
        
        conn.commit()
        conn.close()
        return redirect(url_for('routes.profile'))
    
    conn = get_db_connection()
    plan = conn.execute("SELECT * FROM plans WHERE id = ?", (plan_id,)).fetchone()
    conn.close()
    return render_template('order.html', plan=plan)